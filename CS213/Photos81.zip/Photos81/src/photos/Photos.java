package photos;

public class Photos 
{
	/**
	 * starts the program
	 */
	public static void main(String[] args) 
	{
		SceneChanger.main(args);
	}

}
